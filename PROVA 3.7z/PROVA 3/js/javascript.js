

$(document).ready(function(){

    $("#contacte").on("click",function(){
        
       $("#contingut").load("html/formulari.html #container");
        

        
    });

    $("#geo").on("click",function(){
        
        $("#contingut").load("html/localitzacio.html");
      
 
         
     });
     
            
      
 
         
     });


     







